# Telegram Support Bot

Production-ready Uzbek Telegram support bot built with Node.js, Telegraf and SQLite.

## Features

- `/start`, `/help`, `/cancel`
- Uzbek Telegram-style inline keyboard
- Services menu
- FAQ auto answers
- Unknown questions sent to admin
- Problem reports sent to admin
- Direct admin contact
- Persistent SQLite database
- Multiple users at the same time
- User ID / username / first name saved
- Request IDs and statuses
- Admin panel
- Statistics
- User list
- Support request list
- Broadcast
- `/reply REQUEST_ID message`
- `/close REQUEST_ID`
- Admin can reply to a forwarded support notification
- Admin reply is delivered to the original Telegram user
- Basic media forwarding
- Error handling
- Environment variables for secrets

## 1. Create the bot

Open Telegram and talk to BotFather.

Create a bot and copy its token.

Get your own Telegram numeric ID using a trusted Telegram ID bot or another method you control.

## 2. Configure

Copy `.env.example` to `.env`.

Set:

BOT_TOKEN=your_bot_token
ADMIN_ID=your_numeric_telegram_id

Never commit `.env` to GitHub.

## 3. Install

```bash
npm install
```

## 4. Run

```bash
npm start
```

For development:

```bash
npm run dev
```

## 5. Admin

Send `/admin` from the configured admin account.

The admin panel contains:

- Statistics
- Users
- Support requests
- Broadcast
- Settings

## Direct reply

When a support request arrives, reply directly to the bot's notification message in the admin chat.

The bot maps the notification to the original user and sends:

👨‍💻 Administrator javobi:

[your message]

## FAQ

FAQ entries are in `src/index.js` inside the `faq` array.

Add more keywords and answers there.

## Production

For a VPS:

1. Install Node.js 20+.
2. Upload the project.
3. Create `.env`.
4. Run `npm install`.
5. Run `npm start`.
6. Use a process manager such as systemd or PM2 if desired.
7. Back up `data/support.db`.

This version uses Telegram long polling, so no public HTTPS webhook is required.
