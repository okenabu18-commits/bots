require("dotenv").config();

const { Telegraf, Markup } = require("telegraf");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const BOT_TOKEN = process.env.BOT_TOKEN;
const ADMIN_ID = Number(process.env.ADMIN_ID);
const BOT_NAME = process.env.BOT_NAME || "Support Bot";
const TIMEZONE = process.env.TIMEZONE || "Asia/Tashkent";

if (!BOT_TOKEN || !Number.isInteger(ADMIN_ID) || ADMIN_ID <= 0) {
  console.error("BOT_TOKEN va ADMIN_ID .env faylida to'g'ri sozlanishi kerak.");
  process.exit(1);
}

const DATA_DIR = path.join(process.cwd(), "data");
fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, "support.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  username TEXT,
  first_name TEXT NOT NULL DEFAULT '',
  last_name TEXT,
  created_at TEXT NOT NULL,
  last_seen TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  kind TEXT NOT NULL,
  user_message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  admin_message_id INTEGER,
  created_at TEXT NOT NULL,
  answered_at TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_requests_user ON requests(user_id);
CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status);
`);

const sessions = new Map();

const faq = [
  {
    keys: ["xizmat", "xizmatlar", "nima xizmat"],
    answer: "🛠 Biz quyidagi xizmatlarni taklif qilamiz:\n\n1️⃣ Web sayt yaratish\n2️⃣ Telegram bot yaratish\n3️⃣ AI bot yaratish\n4️⃣ Dizayn va UI/UX\n5️⃣ Texnik yordam\n\nKerakli xizmatni tanlash uchun «🛠 Xizmatlar» bo‘limiga kiring."
  },
  {
    keys: ["web sayt", "sayt", "website"],
    answer: "🌐 Web sayt yaratish xizmatida landing page, biznes sayt va boshqa zamonaviy web loyihalarni tayyorlashimiz mumkin. Aniq narx loyiha talablariga qarab belgilanadi."
  },
  {
    keys: ["telegram bot", "bot yaratish", "telegram bot yaratish"],
    answer: "🤖 Telegram botlar uchun menyu, support, avtomatik javoblar, admin panel va boshqa funksiyalarni ishlab chiqishimiz mumkin. Loyiha tafsilotlarini yuborsangiz, administrator aniq ma’lumot beradi."
  },
  {
    keys: ["ai bot", "suniy intellekt", "sun'iy intellekt", "ai"],
    answer: "🧠 AI botlar uchun FAQ, AI javoblari, support va boshqa avtomatlashtirish imkoniyatlarini ulash mumkin. Kerakli funksiyalarni yozib yuboring."
  },
  {
    keys: ["narx", "price", "qancha", "necha pul", "цена"],
    answer: "💰 Narx xizmat va loyiha hajmiga bog‘liq. Qaysi xizmat kerakligini yozsangiz, administrator sizga aniq narx bo‘yicha ma’lumot beradi."
  },
  {
    keys: ["to'lov", "tolov", "оплата", "payment"],
    answer: "💳 To‘lov bo‘yicha aniq ma’lumot olish uchun administratorga murojaat qiling. «👨‍💻 Admin bilan bog‘lanish» tugmasidan foydalanishingiz mumkin."
  },
  {
    keys: ["aloqa", "admin", "administrator", "bog'lanish"],
    answer: "👨‍💻 Administrator bilan bog‘lanish uchun «👨‍💻 Admin bilan bog‘lanish» tugmasini bosing va xabaringizni yuboring."
  },
  {
    keys: ["salom", "assalomu alaykum", "hello", "hi"],
    answer: "👋 Va alaykum assalom! Qanday yordam bera olaman? «🛠 Xizmatlar» yoki «❓ Savol berish» bo‘limidan foydalanishingiz mumkin."
  }
];

const mainKeyboard = Markup.inlineKeyboard([
  [Markup.button.callback("🛠 Xizmatlar", "services")],
  [Markup.button.callback("❓ Savol berish", "question")],
  [Markup.button.callback("🐛 Muammo haqida", "problem")],
  [Markup.button.callback("👨‍💻 Admin bilan bog‘lanish", "admin_contact")]
]);

const adminKeyboard = Markup.inlineKeyboard([
  [Markup.button.callback("📊 Statistics", "admin_stats"), Markup.button.callback("👥 Users", "admin_users")],
  [Markup.button.callback("📩 Support requests", "admin_requests")],
  [Markup.button.callback("📢 Broadcast", "admin_broadcast")],
  [Markup.button.callback("⚙️ Settings", "admin_settings")]
]);

const serviceKeyboard = Markup.inlineKeyboard([
  [Markup.button.callback("🌐 Web sayt", "service_web")],
  [Markup.button.callback("🤖 Telegram bot", "service_telegram")],
  [Markup.button.callback("🧠 AI bot", "service_ai")],
  [Markup.button.callback("🎨 Dizayn / UI/UX", "service_design")],
  [Markup.button.callback("🛠 Texnik yordam", "service_support")],
  [Markup.button.callback("⬅️ Bosh menyu", "home")]
]);

function now() {
  return new Intl.DateTimeFormat("uz-UZ", {
    timeZone: TIMEZONE,
    dateStyle: "short",
    timeStyle: "medium"
  }).format(new Date());
}

function upsertUser(from) {
  const timestamp = now();
  db.prepare(`
    INSERT INTO users (id, username, first_name, last_name, created_at, last_seen)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      username=excluded.username,
      first_name=excluded.first_name,
      last_name=excluded.last_name,
      last_seen=excluded.last_seen
  `).run(
    from.id,
    from.username || null,
    from.first_name || "",
    from.last_name || null,
    timestamp,
    timestamp
  );
}

function isAdmin(ctx) {
  return Number(ctx.from?.id) === ADMIN_ID;
}

function userLabel(from) {
  const username = from.username ? `@${from.username}` : "username yo‘q";
  return `👤 User: ${from.first_name || "Noma'lum"}\n🆔 Telegram ID: ${from.id}\n🔗 Username: ${username}`;
}

function findFaq(text) {
  const normalized = text.toLowerCase().replace(/[ʻʼ’‘]/g, "'");
  let best = null;
  let bestScore = 0;

  for (const item of faq) {
    let score = 0;
    for (const key of item.keys) {
      if (normalized.includes(key.toLowerCase())) score += key.length;
    }
    if (score > bestScore) {
      bestScore = score;
      best = item.answer;
    }
  }

  return bestScore >= 4 ? best : null;
}

function setSession(userId, state) {
  sessions.set(userId, { state, createdAt: Date.now() });
}

function clearSession(userId) {
  sessions.delete(userId);
}

function createRequest(user, kind, message) {
  const result = db.prepare(`
    INSERT INTO requests (user_id, kind, user_message, status, created_at)
    VALUES (?, ?, ?, 'pending', ?)
  `).run(user.id, kind, message, now());

  return Number(result.lastInsertRowid);
}

async function notifyAdmin(ctx, requestId, kind, message) {
  const text =
`📩 YANGI SUPPORT XABARI

${userLabel(ctx.from)}

🆔 Request ID: #${requestId}
📂 Turi: ${kind}

📝 Xabar:
${message}

⏰ Vaqt:
${now()}

↩️ Javob berish uchun shu xabarga Reply qiling.`;

  const sent = await ctx.telegram.sendMessage(
    ADMIN_ID,
    text,
    { reply_markup: Markup.inlineKeyboard([
      [Markup.button.callback(`💬 Javob berish #${requestId}`, `reply_req:${requestId}`)],
      [Markup.button.callback(`✅ Yopish #${requestId}`, `close_req:${requestId}`)]
    ]).reply_markup }
  );

  db.prepare("UPDATE requests SET admin_message_id=? WHERE id=?")
    .run(sent.message_id, requestId);

  return sent;
}

async function sendHome(ctx) {
  await ctx.reply(
`👋 Assalomu alaykum!
Support botimizga xush kelibsiz.

Bu bot orqali:
🛠 Xizmatlar haqida ma'lumot olishingiz mumkin
❓ Savollaringizni berishingiz mumkin
🐛 Muammo haqida xabar berishingiz mumkin
👨‍💻 Kerak bo'lsa, administrator bilan bog'lanishingiz mumkin.`,
    mainKeyboard
  );
}

async function processSupportText(ctx, state, text) {
  if (!text || !text.trim()) {
    await ctx.reply("✍️ Iltimos, xabaringizni matn ko‘rinishida yuboring.");
    return;
  }

  const clean = text.trim();
  const userId = ctx.from.id;

  if (state === "question") {
    const answer = findFaq(clean);
    if (answer) {
      clearSession(userId);
      await ctx.reply(answer, mainKeyboard);
      return;
    }

    const requestId = createRequest(ctx.from, "Savol", clean);
    try {
      await notifyAdmin(ctx, requestId, "Savol", clean);
      clearSession(userId);
      await ctx.reply(
`⚠️ Bu savolga hozir aniq javob bera olmadim.

📨 Savolingiz adminga yuborildi.
Administrator siz bilan bog‘lanadi.

Rahmat! 🙏`,
        mainKeyboard
      );
    } catch (err) {
      console.error("Admin notification error:", err);
      await ctx.reply("⚠️ Xabarni yuborishda texnik xatolik yuz berdi. Iltimos, birozdan so‘ng qayta urinib ko‘ring.");
    }
    return;
  }

  const kind = state === "problem" ? "Muammo" : "Admin bilan bog‘lanish";
  const requestId = createRequest(ctx.from, kind, clean);

  try {
    await notifyAdmin(ctx, requestId, kind, clean);
    clearSession(userId);

    if (state === "problem") {
      await ctx.reply(
`✅ Muammoingiz qabul qilindi.

📨 Xabaringiz adminga yuborildi.
👨‍💻 Administrator muammoni ko‘rib chiqadi va siz bilan bog‘lanadi.`,
        mainKeyboard
      );
    } else {
      await ctx.reply(
`✅ Xabaringiz adminga yuborildi.

Administrator tez orada siz bilan bog‘lanadi.`,
        mainKeyboard
      );
    }
  } catch (err) {
    console.error("Support request error:", err);
    await ctx.reply("⚠️ Xabarni yuborishda texnik xatolik yuz berdi. Iltimos, qayta urinib ko‘ring.");
  }
}

const bot = new Telegraf(BOT_TOKEN);

bot.use(async (ctx, next) => {
  if (ctx.from) upsertUser(ctx.from);
  return next();
});

bot.start(async ctx => {
  clearSession(ctx.from.id);
  await sendHome(ctx);
});

bot.command("help", async ctx => {
  await ctx.reply(
`ℹ️ Yordam

🛠 Xizmatlar — mavjud xizmatlar
❓ Savol berish — savolingizni yuborish
🐛 Muammo haqida — texnik muammo yuborish
👨‍💻 Admin bilan bog‘lanish — administratorga yozish

/cancel — joriy amalni bekor qilish`,
    mainKeyboard
  );
});

bot.command("cancel", async ctx => {
  clearSession(ctx.from.id);
  await ctx.reply("✅ Joriy amal bekor qilindi.", mainKeyboard);
});

bot.command("admin", async ctx => {
  if (!isAdmin(ctx)) return ctx.reply("⛔ Bu buyruq faqat administrator uchun.");
  await ctx.reply(`⚙️ ${BOT_NAME} — Admin Panel`, adminKeyboard);
});

bot.command("stats", async ctx => {
  if (!isAdmin(ctx)) return ctx.reply("⛔ Ruxsat yo‘q.");
  await sendStats(ctx);
});

bot.command("users", async ctx => {
  if (!isAdmin(ctx)) return ctx.reply("⛔ Ruxsat yo‘q.");
  await sendUsers(ctx);
});

bot.command("broadcast", async ctx => {
  if (!isAdmin(ctx)) return ctx.reply("⛔ Ruxsat yo‘q.");
  setSession(ctx.from.id, "broadcast");
  await ctx.reply("📢 Barcha faol foydalanuvchilarga yuboriladigan xabarni yozing.\n/cancel — bekor qilish");
});

bot.command("reply", async ctx => {
  if (!isAdmin(ctx)) return ctx.reply("⛔ Ruxsat yo‘q.");
  const parts = ctx.message.text.split(" ");
  const requestId = Number(parts[1]);
  const message = parts.slice(2).join(" ").trim();

  if (!requestId || !message) {
    return ctx.reply("Format: /reply REQUEST_ID xabar");
  }

  await replyToRequest(ctx, requestId, message);
});

bot.command("close", async ctx => {
  if (!isAdmin(ctx)) return ctx.reply("⛔ Ruxsat yo‘q.");
  const requestId = Number(ctx.message.text.split(" ")[1]);
  if (!requestId) return ctx.reply("Format: /close REQUEST_ID");
  await closeRequest(ctx, requestId);
});

bot.action("home", async ctx => {
  await ctx.answerCbQuery();
  clearSession(ctx.from.id);
  await sendHome(ctx);
});

bot.action("services", async ctx => {
  await ctx.answerCbQuery();
  await ctx.editMessageText(
`🛠 Bizning xizmatlar:

1️⃣ Web sayt yaratish
2️⃣ Telegram bot yaratish
3️⃣ AI bot yaratish
4️⃣ Dizayn va UI/UX
5️⃣ Texnik yordam

Kerakli xizmatni tanlang.`,
    serviceKeyboard
  );
});

const serviceTexts = {
  service_web: "🌐 Web sayt yaratish\n\nZamonaviy landing page, biznes sayt va boshqa web loyihalar. Aniq narx loyiha talablariga qarab belgilanadi.",
  service_telegram: "🤖 Telegram bot yaratish\n\nSupport, menyu, avtomatik javob, admin panel va boshqa funksiyalar.",
  service_ai: "🧠 AI bot yaratish\n\nFAQ, AI javoblari, support va avtomatlashtirish imkoniyatlari.",
  service_design: "🎨 Dizayn va UI/UX\n\nWeb va bot interfeyslari uchun zamonaviy UI/UX dizayn.",
  service_support: "🛠 Texnik yordam\n\nMavjud loyiha yoki xizmatdagi muammolarni aniqlash va texnik yordam."
};

for (const [action, text] of Object.entries(serviceTexts)) {
  bot.action(action, async ctx => {
    await ctx.answerCbQuery();
    await ctx.editMessageText(text, Markup.inlineKeyboard([
      [Markup.button.callback("👨‍💻 Admin bilan bog‘lanish", "admin_contact")],
      [Markup.button.callback("⬅️ Xizmatlarga qaytish", "services")]
    ]));
  });
}

bot.action("question", async ctx => {
  await ctx.answerCbQuery();
  setSession(ctx.from.id, "question");
  await ctx.reply("✍️ Savolingizni yozib yuboring.\nMuammoingizni imkon qadar batafsil yozing.\n\n/cancel — bekor qilish");
});

bot.action("problem", async ctx => {
  await ctx.answerCbQuery();
  setSession(ctx.from.id, "problem");
  await ctx.reply(
`🐛 Muammoingizni yozib yuboring.

Masalan:
• Sayt ishlamayapti
• Bot javob bermayapti
• To‘lov bilan muammo bor
• Xizmat ishlamayapti

Muammoingizni batafsil yozing.

/cancel — bekor qilish`
  );
});

bot.action("admin_contact", async ctx => {
  await ctx.answerCbQuery();
  setSession(ctx.from.id, "admin_contact");
  await ctx.reply("👨‍💻 Administrator bilan bog‘lanish uchun xabaringizni yozing.\n\n/cancel — bekor qilish");
});

async function sendStats(ctx) {
  const totalUsers = db.prepare("SELECT COUNT(*) AS c FROM users").get().c;
  const total = db.prepare("SELECT COUNT(*) AS c FROM requests").get().c;
  const answered = db.prepare("SELECT COUNT(*) AS c FROM requests WHERE status='answered'").get().c;
  const pending = db.prepare("SELECT COUNT(*) AS c FROM requests WHERE status='pending'").get().c;

  await ctx.reply(
`📊 STATISTICS

👥 Total users: ${totalUsers}
📩 Total support requests: ${total}
✅ Answered requests: ${answered}
⏳ Pending requests: ${pending}`
  );
}

async function sendUsers(ctx) {
  const users = db.prepare(`
    SELECT id, first_name, username, last_seen
    FROM users
    ORDER BY last_seen DESC
    LIMIT 20
  `).all();

  if (!users.length) return ctx.reply("👥 Hozircha foydalanuvchilar yo‘q.");

  const lines = users.map((u, i) =>
    `${i + 1}. ${u.first_name || "Noma'lum"} — ${u.username ? "@" + u.username : "username yo‘q"}\nID: ${u.id}\nOxirgi faollik: ${u.last_seen}`
  );

  await ctx.reply("👥 Oxirgi foydalanuvchilar:\n\n" + lines.join("\n\n"));
}

async function sendRequests(ctx) {
  const rows = db.prepare(`
    SELECT r.id, r.kind, r.status, r.created_at, u.first_name, u.username
    FROM requests r
    JOIN users u ON u.id = r.user_id
    ORDER BY r.id DESC
    LIMIT 20
  `).all();

  if (!rows.length) return ctx.reply("📩 Hozircha support requestlar yo‘q.");

  const text = rows.map(r =>
    `#${r.id} • ${r.status === "pending" ? "⏳" : "✅"} ${r.kind}\n👤 ${r.first_name || "Noma'lum"} ${r.username ? "(@" + r.username + ")" : ""}\n⏰ ${r.created_at}`
  ).join("\n\n");

  await ctx.reply("📩 SUPPORT REQUESTS\n\n" + text);
}

async function replyToRequest(ctx, requestId, message) {
  const req = db.prepare("SELECT * FROM requests WHERE id=?").get(requestId);
  if (!req) return ctx.reply("❌ Request topilmadi.");

  try {
    await ctx.telegram.sendMessage(
      req.user_id,
`👨‍💻 Administrator javobi:

${message}`
    );

    db.prepare(`
      UPDATE requests
      SET status='answered', answered_at=?
      WHERE id=?
    `).run(now(), requestId);

    await ctx.reply(`✅ Javob foydalanuvchiga yuborildi.\nRequest: #${requestId}`);
  } catch (err) {
    console.error("Reply error:", err);
    await ctx.reply("❌ Foydalanuvchiga javob yuborilmadi. U botni bloklagan bo‘lishi mumkin.");
  }
}

async function closeRequest(ctx, requestId) {
  const req = db.prepare("SELECT * FROM requests WHERE id=?").get(requestId);
  if (!req) return ctx.reply("❌ Request topilmadi.");

  db.prepare(`
    UPDATE requests SET status='answered', answered_at=?
    WHERE id=?
  `).run(now(), requestId);

  try {
    await ctx.telegram.sendMessage(req.user_id, "✅ Sizning support murojaatingiz yopildi. Yangi savol bo‘lsa, istalgan vaqtda yozishingiz mumkin.");
  } catch {}
  await ctx.reply(`✅ Request #${requestId} yopildi.`);
}

bot.action("admin_stats", async ctx => {
  await ctx.answerCbQuery();
  if (!isAdmin(ctx)) return;
  await sendStats(ctx);
});

bot.action("admin_users", async ctx => {
  await ctx.answerCbQuery();
  if (!isAdmin(ctx)) return;
  await sendUsers(ctx);
});

bot.action("admin_requests", async ctx => {
  await ctx.answerCbQuery();
  if (!isAdmin(ctx)) return;
  await sendRequests(ctx);
});

bot.action("admin_broadcast", async ctx => {
  await ctx.answerCbQuery();
  if (!isAdmin(ctx)) return;
  setSession(ctx.from.id, "broadcast");
  await ctx.reply("📢 Broadcast xabarini yozing.\n/cancel — bekor qilish");
});

bot.action("admin_settings", async ctx => {
  await ctx.answerCbQuery();
  if (!isAdmin(ctx)) return;
  await ctx.reply(
`⚙️ SETTINGS

🤖 Bot: ${BOT_NAME}
🌍 Til: Uzbek
🕒 Timezone: ${TIMEZONE}
💾 Database: SQLite
🔐 Admin ID: yashirilgan`
  );
});

bot.action(/^reply_req:(\d+)$/, async ctx => {
  await ctx.answerCbQuery();
  if (!isAdmin(ctx)) return;

  const requestId = Number(ctx.match[1]);
  setSession(ctx.from.id, `reply:${requestId}`);
  await ctx.reply(`💬 #${requestId} request uchun javobni yozing.`);
});

bot.action(/^close_req:(\d+)$/, async ctx => {
  await ctx.answerCbQuery();
  if (!isAdmin(ctx)) return;

  await closeRequest(ctx, Number(ctx.match[1]));
});

bot.on("text", async ctx => {
  const text = ctx.message.text;
  const session = sessions.get(ctx.from.id);

  if (!session) {
    const answer = findFaq(text);
    if (answer) return ctx.reply(answer, mainKeyboard);
    return ctx.reply("🤔 Savolingizni tushunmadim. «❓ Savol berish» tugmasini bosing yoki «👨‍💻 Admin bilan bog‘lanish» orqali yozing.", mainKeyboard);
  }

  if (session.state === "broadcast") {
    if (!isAdmin(ctx)) return;
    clearSession(ctx.from.id);

    const users = db.prepare("SELECT id FROM users").all();
    let sent = 0, failed = 0;

    for (const u of users) {
      try {
        await ctx.telegram.sendMessage(u.id, `📢 Yangilik\n\n${text}`);
        sent++;
      } catch {
        failed++;
      }
    }

    return ctx.reply(`📢 Broadcast tugadi.\n\n✅ Yuborildi: ${sent}\n❌ Yuborilmadi: ${failed}`);
  }

  if (session.state.startsWith("reply:")) {
    if (!isAdmin(ctx)) return;
    const requestId = Number(session.state.split(":")[1]);
    clearSession(ctx.from.id);
    return replyToRequest(ctx, requestId, text);
  }

  return processSupportText(ctx, session.state, text);
});

bot.on(["photo", "document", "voice", "video", "audio"], async ctx => {
  const session = sessions.get(ctx.from.id);
  if (!session || !["question", "problem", "admin_contact"].includes(session.state)) return;

  const caption = ctx.message.caption || "(Fayl yuborildi)";
  const kind = session.state === "question" ? "Savol + fayl" :
               session.state === "problem" ? "Muammo + fayl" : "Admin bilan bog‘lanish + fayl";

  const requestId = createRequest(ctx.from, kind, caption);

  try {
    await ctx.telegram.forwardMessage(ADMIN_ID, ctx.chat.id, ctx.message.message_id);
    await ctx.telegram.sendMessage(
      ADMIN_ID,
`📩 YANGI SUPPORT XABARI

${userLabel(ctx.from)}

🆔 Request ID: #${requestId}
📂 Turi: ${kind}

📝 Izoh:
${caption}

⏰ Vaqt:
${now()}

↩️ Foydalanuvchiga javob berish uchun ushbu xabarga Reply qiling.`
    );

    clearSession(ctx.from.id);
    await ctx.reply(
      session.state === "problem"
        ? "✅ Muammoingiz qabul qilindi.\n\n📨 Xabaringiz adminga yuborildi.\n👨‍💻 Administrator muammoni ko‘rib chiqadi va siz bilan bog‘lanadi."
        : "📨 Savolingiz adminga yuborildi.",
      mainKeyboard
    );
  } catch (err) {
    console.error("Media support error:", err);
    await ctx.reply("⚠️ Xabarni yuborishda xatolik yuz berdi.");
  }
});

// Direct Telegram reply support: admin replies to the original notification.
// Telegram gives us the replied-to message, whose ID is stored in requests.admin_message_id.
bot.on("message", async ctx => {
  if (!isAdmin(ctx) || !ctx.message.reply_to_message) return;

  const repliedId = ctx.message.reply_to_message.message_id;
  const req = db.prepare(`
    SELECT * FROM requests WHERE admin_message_id=? ORDER BY id DESC LIMIT 1
  `).get(repliedId);

  if (!req) return;

  let text = "";
  if ("text" in ctx.message) text = ctx.message.text;
  else if ("caption" in ctx.message) text = ctx.message.caption || "";

  if (!text) {
    return ctx.reply("⚠️ Hozircha admin javoblari matn ko‘rinishida yuborilishi kerak.");
  }

  await replyToRequest(ctx, req.id, text);
});

bot.catch((err, ctx) => {
  console.error("BOT ERROR:", err);
  try {
    if (ctx?.chat?.id) ctx.telegram.sendMessage(ctx.chat.id, "⚠️ Kutilmagan texnik xatolik yuz berdi. Iltimos, qayta urinib ko‘ring.");
  } catch {}
});

(async () => {
  try {
    await bot.launch();
    console.log(`✅ ${BOT_NAME} ishga tushdi.`);
    console.log(`👨‍💻 Admin ID: ${ADMIN_ID}`);
  } catch (err) {
    console.error("Bot launch error:", err);
    process.exit(1);
  }
})();

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
