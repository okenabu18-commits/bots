const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const KEY_PATH = path.join(__dirname, 'data', '.secret.key');

// Generate (once) or load a local encryption key. This key never leaves the server,
// is never sent to the frontend, and is never logged.
function getKey() {
  if (fs.existsSync(KEY_PATH)) {
    return fs.readFileSync(KEY_PATH);
  }
  const key = crypto.randomBytes(32);
  fs.mkdirSync(path.dirname(KEY_PATH), { recursive: true });
  fs.writeFileSync(KEY_PATH, key, { mode: 0o600 });
  return key;
}

function encrypt(plainText) {
  const key = getKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(String(plainText), 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return Buffer.concat([iv, authTag, encrypted]).toString('base64');
}

function decrypt(payloadB64) {
  const key = getKey();
  const raw = Buffer.from(payloadB64, 'base64');
  const iv = raw.subarray(0, 12);
  const authTag = raw.subarray(12, 28);
  const encrypted = raw.subarray(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);
  const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
  return decrypted.toString('utf8');
}

// Masks a token for safe display/logging, e.g. "123456:AAxx...w9Q" -> "123456:••••••w9Q"
function maskToken(token) {
  if (!token || typeof token !== 'string') return '';
  const parts = token.split(':');
  if (parts.length !== 2) return '••••••';
  const tail = parts[1].slice(-4);
  return `${parts[0]}:${'•'.repeat(6)}${tail}`;
}

module.exports = { encrypt, decrypt, maskToken };
