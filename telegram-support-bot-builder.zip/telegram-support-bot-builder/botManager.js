const TelegramBot = require('node-telegram-bot-api');
const store = require('./store');
const { encrypt, decrypt, maskToken } = require('./crypto-util');

// ---- in-memory runtime state (never persisted, never exposed via API) ----
let bot = null;
let status = 'Offline'; // Offline | Starting | Online | Error
let lastError = null;
let botUsername = null;
let startedAt = null;
let adminId = null;
let botName = null;

// chatId -> { awaitingReport: boolean }
const conversationState = new Map();
// userId -> array of recent action timestamps (ms), for rate limiting
const rateLimitMap = new Map();

const RATE_LIMIT_WINDOW_MS = 10_000;
const RATE_LIMIT_MAX_ACTIONS = 8;

function isRateLimited(userId) {
  const now = Date.now();
  const arr = (rateLimitMap.get(userId) || []).filter((t) => now - t < RATE_LIMIT_WINDOW_MS);
  arr.push(now);
  rateLimitMap.set(userId, arr);
  return arr.length > RATE_LIMIT_MAX_ACTIONS;
}

function sanitizeText(text) {
  if (typeof text !== 'string') return '';
  // Strip control characters and cap length; Telegram already sends plain text
  // (not HTML), so no HTML-escaping is needed for MarkdownV2-free plain sends.
  return text.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').slice(0, 2000).trim();
}

async function validateToken(token) {
  if (!token || typeof token !== 'string' || !/^\d+:[\w-]{20,}$/.test(token)) {
    return { valid: false, error: 'Token format looks invalid.' };
  }
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/getMe`, { method: 'GET' });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      return { valid: false, error: data.description || 'Telegram rejected this token.' };
    }
    return { valid: true, username: data.result.username, name: data.result.first_name };
  } catch (err) {
    return { valid: false, error: 'Could not reach Telegram API. Check your connection.' };
  }
}

function mainMenuKeyboard() {
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'ℹ️ About', callback_data: 'about' }],
        [{ text: '🆘 Help', callback_data: 'help' }],
        [{ text: '⚠️ Report a mistake', callback_data: 'report' }],
      ],
    },
  };
}

function backKeyboard() {
  return { reply_markup: { inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'back' }]] } };
}

function registerHandlers() {
  bot.onText(/^\/start$/, async (msg) => {
    const chatId = msg.chat.id;
    conversationState.delete(chatId);
    if (isRateLimited(msg.from.id)) return;
    store.touchUser({ userId: msg.from.id, username: msg.from.username, fullName: fullNameOf(msg.from) });
    await bot.sendMessage(chatId, '👋 Welcome!\nChoose an option below:', mainMenuKeyboard());
  });

  bot.onText(/^\/cancel$/, async (msg) => {
    const chatId = msg.chat.id;
    if (conversationState.get(chatId)?.awaitingReport) {
      conversationState.delete(chatId);
      await bot.sendMessage(chatId, '❌ Report cancelled.', mainMenuKeyboard());
    }
  });

  bot.onText(/^\/admin$/, async (msg) => {
    const chatId = msg.chat.id;
    if (isRateLimited(msg.from.id)) return;
    if (String(msg.from.id) !== String(adminId)) {
      await bot.sendMessage(chatId, '🚫 You are not authorized to use this command.');
      return;
    }
    const reports = store.getReports();
    const newCount = reports.filter((r) => r.status === 'New').length;
    const text =
      `⚙️ Admin Panel\n\n` +
      `📊 Bot Status: ${status}\n` +
      `👥 Users: ${store.countUsers()}\n` +
      `📨 Reports: ${reports.length} total, ${newCount} new\n\n` +
      `Use the website dashboard to review and update report statuses.`;
    await bot.sendMessage(chatId, text);
  });

  bot.on('callback_query', async (query) => {
    const chatId = query.message.chat.id;
    const data = query.data;
    if (isRateLimited(query.from.id)) {
      await bot.answerCallbackQuery(query.id);
      return;
    }
    try {
      if (data === 'about') {
        await bot.editMessageText(
          'ℹ️ About\n\nThis is the official support bot.\nUse this bot to get help or report problems.',
          { chat_id: chatId, message_id: query.message.message_id, ...backKeyboard() }
        );
      } else if (data === 'help') {
        await bot.editMessageText(
          '🆘 Help\n\nIf you have a problem, use the Report a mistake button and describe the problem.',
          { chat_id: chatId, message_id: query.message.message_id, ...backKeyboard() }
        );
      } else if (data === 'report') {
        conversationState.set(chatId, { awaitingReport: true });
        await bot.editMessageText(
          '⚠️ Report a mistake\n\nPlease describe the problem in your next message.\n\nType /cancel to cancel.',
          { chat_id: chatId, message_id: query.message.message_id }
        );
      } else if (data === 'back') {
        conversationState.delete(chatId);
        await bot.editMessageText('👋 Welcome!\nChoose an option below:', {
          chat_id: chatId,
          message_id: query.message.message_id,
          ...mainMenuKeyboard(),
        });
      }
      await bot.answerCallbackQuery(query.id);
    } catch (err) {
      await bot.answerCallbackQuery(query.id).catch(() => {});
    }
  });

  bot.on('message', async (msg) => {
    // Ignore commands (handled above) and non-text messages for the report flow.
    if (!msg.text || msg.text.startsWith('/')) return;
    const chatId = msg.chat.id;
    const state = conversationState.get(chatId);
    if (!state?.awaitingReport) return;
    if (isRateLimited(msg.from.id)) {
      await bot.sendMessage(chatId, '⏳ Too many actions, please slow down.');
      return;
    }

    const cleanText = sanitizeText(msg.text);
    if (!cleanText) {
      await bot.sendMessage(chatId, 'Please send a text description of the problem, or /cancel.');
      return;
    }

    conversationState.delete(chatId);
    const fullName = fullNameOf(msg.from);
    const report = store.addReport({
      userId: msg.from.id,
      username: msg.from.username,
      fullName,
      message: cleanText,
    });
    store.touchUser({ userId: msg.from.id, username: msg.from.username, fullName });

    const adminText =
      `🚨 NEW MISTAKE REPORT\n\n` +
      `👤 Name: ${fullName}\n` +
      `🔗 Username: ${msg.from.username ? '@' + msg.from.username : 'N/A'}\n` +
      `🆔 User ID: ${msg.from.id}\n\n` +
      `📝 Report:\n${cleanText}\n\n` +
      `(Report ID: ${report.id})`;

    try {
      await bot.sendMessage(adminId, adminText);
    } catch (err) {
      // Admin may not have started the bot yet, or ID may be wrong. The report is
      // still saved and visible in the dashboard even if delivery fails.
      console.error('Failed to deliver report to admin:', err.message);
    }

    await bot.sendMessage(
      chatId,
      '✅ Your report has been sent to the admin.\nThank you for helping us improve.'
    );
    await bot.sendMessage(chatId, '👋 Welcome!\nChoose an option below:', mainMenuKeyboard());
  });

  bot.on('polling_error', (err) => {
    console.error('Polling error:', err.message);
    status = 'Error';
    lastError = err.message.includes('409')
      ? 'Another instance of this bot is already running (Telegram allows only one).'
      : err.message;
  });
}

function fullNameOf(from) {
  return [from.first_name, from.last_name].filter(Boolean).join(' ') || 'Unknown';
}

async function startBot({ token, admin, name }) {
  if (status === 'Online' || status === 'Starting') {
    return { ok: false, error: 'Bot already running.' };
  }
  if (!admin || !/^\d+$/.test(String(admin))) {
    return { ok: false, error: 'Missing or invalid Admin Telegram ID.' };
  }

  status = 'Starting';
  lastError = null;

  const validation = await validateToken(token);
  if (!validation.valid) {
    status = 'Error';
    lastError = validation.error;
    return { ok: false, error: validation.error };
  }

  try {
    store.saveConfig({
      tokenEncrypted: encrypt(token),
      tokenMasked: maskToken(token),
      admin: String(admin),
      name: name || validation.username,
    });

    bot = new TelegramBot(token, { polling: true });
    registerHandlers();

    adminId = String(admin);
    botName = name || validation.username;
    botUsername = validation.username;
    startedAt = Date.now();
    status = 'Online';
    lastError = null;

    return { ok: true, username: botUsername };
  } catch (err) {
    status = 'Error';
    lastError = err.message;
    return { ok: false, error: 'Failed to start bot: ' + err.message };
  }
}

async function stopBot() {
  if (!bot) {
    status = 'Offline';
    return { ok: true };
  }
  try {
    await bot.stopPolling();
  } catch (err) {
    // ignore
  }
  bot = null;
  status = 'Offline';
  startedAt = null;
  lastError = null;
  conversationState.clear();
  return { ok: true };
}

async function restartBot() {
  const cfg = store.getConfig();
  if (!cfg) return { ok: false, error: 'No saved bot configuration to restart.' };
  await stopBot();
  const token = decrypt(cfg.tokenEncrypted);
  return startBot({ token, admin: cfg.admin, name: cfg.name });
}

// Attempt to resume a previously running bot on server restart.
async function resumeFromSavedConfig() {
  const cfg = store.getConfig();
  if (!cfg) return;
  try {
    const token = decrypt(cfg.tokenEncrypted);
    await startBot({ token, admin: cfg.admin, name: cfg.name });
  } catch (err) {
    status = 'Error';
    lastError = 'Could not resume saved bot: ' + err.message;
  }
}

async function testBot() {
  if (!bot || status !== 'Online') return { ok: false, error: 'Bot is not online.' };
  try {
    await bot.sendMessage(adminId, '🧪 Test message: your bot is online and can reach Telegram.');
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function logout() {
  await stopBot();
  store.clearConfig();
  adminId = null;
  botName = null;
  botUsername = null;
  return { ok: true };
}

function getStatus() {
  const cfg = store.getConfig();
  return {
    status,
    error: lastError,
    username: botUsername,
    name: botName,
    uptimeSeconds: startedAt ? Math.floor((Date.now() - startedAt) / 1000) : 0,
    hasSavedConfig: !!cfg,
    tokenMasked: cfg ? cfg.tokenMasked : null,
    adminId: cfg ? cfg.admin : null,
    // NOTE: raw token is intentionally never included anywhere in this object.
  };
}

module.exports = {
  validateToken,
  startBot,
  stopBot,
  restartBot,
  resumeFromSavedConfig,
  testBot,
  logout,
  getStatus,
};
