const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const rateLimit = require('express-rate-limit');

const botManager = require('./botManager');
const store = require('./store');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const SESSION_SECRET_PATH = path.join(DATA_DIR, '.session-secret');

function getSessionSecret() {
  if (fs.existsSync(SESSION_SECRET_PATH)) return fs.readFileSync(SESSION_SECRET_PATH, 'utf8');
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const secret = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(SESSION_SECRET_PATH, secret, { mode: 0o600 });
  return secret;
}

app.use(express.json({ limit: '100kb' }));
app.use(
  session({
    secret: getSessionSecret(),
    name: 'tsbb.sid',
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 24 * 7 },
  })
);

const apiLimiter = rateLimit({ windowMs: 60 * 1000, max: 60, standardHeaders: true, legacyHeaders: false });
app.use('/api/', apiLimiter);

function requireAuth(req, res, next) {
  if (req.session && req.session.authenticated) return next();
  return res.status(401).json({ ok: false, error: 'Not authenticated.' });
}

// ---------- Public status (safe: never includes the token) ----------
app.get('/api/status', (req, res) => {
  res.json({ ok: true, ...botManager.getStatus(), authenticated: !!req.session?.authenticated });
});

// ---------- Start bot ----------
app.post('/api/start', async (req, res) => {
  const { token, admin, name } = req.body || {};
  if (!token) return res.status(400).json({ ok: false, error: 'Bot token is required.' });
  if (!admin) return res.status(400).json({ ok: false, error: 'Admin Telegram ID is required.' });

  const result = await botManager.startBot({ token, admin, name });
  if (!result.ok) return res.status(400).json(result);

  req.session.authenticated = true;
  req.session.adminId = String(admin);
  res.json({ ok: true, username: result.username });
});

// ---------- Re-login after a page reload / new browser session ----------
app.post('/api/login', (req, res) => {
  const { admin } = req.body || {};
  const cfg = store.getConfig();
  if (!cfg) return res.status(400).json({ ok: false, error: 'No bot has been configured yet.' });
  if (!admin || String(admin) !== String(cfg.admin)) {
    return res.status(401).json({ ok: false, error: 'Admin ID does not match the configured bot.' });
  }
  req.session.authenticated = true;
  req.session.adminId = String(admin);
  res.json({ ok: true });
});

app.post('/api/stop', requireAuth, async (req, res) => {
  const result = await botManager.stopBot();
  res.json(result);
});

app.post('/api/restart', requireAuth, async (req, res) => {
  const result = await botManager.restartBot();
  if (!result.ok) return res.status(400).json(result);
  res.json(result);
});

app.post('/api/test', requireAuth, async (req, res) => {
  const result = await botManager.testBot();
  if (!result.ok) return res.status(400).json(result);
  res.json(result);
});

app.post('/api/logout', requireAuth, async (req, res) => {
  await botManager.logout();
  req.session.destroy(() => {});
  res.json({ ok: true });
});

// ---------- Reports / admin dashboard ----------
app.get('/api/reports', requireAuth, (req, res) => {
  res.json({ ok: true, reports: store.getReports(), userCount: store.countUsers() });
});

app.post('/api/reports/:id/status', requireAuth, (req, res) => {
  const { status } = req.body || {};
  const updated = store.updateReportStatus(req.params.id, status);
  if (!updated) return res.status(400).json({ ok: false, error: 'Invalid report ID or status.' });
  res.json({ ok: true, report: updated });
});

app.use(express.static(path.join(__dirname, 'public')));

app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Telegram Support Bot Builder running on http://localhost:${PORT}`);
  // Resume a previously running bot if the server process restarted (e.g. after a deploy).
  botManager.resumeFromSavedConfig();
});
