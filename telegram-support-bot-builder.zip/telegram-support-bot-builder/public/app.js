const $ = (id) => document.getElementById(id);

const setupView = $('setup-view');
const dashboardView = $('dashboard-view');
const statusPill = $('status-pill');
const statusText = $('status-text');

let pollTimer = null;
let uptimeBase = 0;
let uptimeTimer = null;

function setStatusPill(status) {
  statusPill.className = 'status-pill status-' + status.toLowerCase();
  statusText.textContent = status;
}

function showAlert(el, message) {
  if (!message) {
    el.classList.add('hidden');
    return;
  }
  el.textContent = message;
  el.classList.remove('hidden');
}

function formatUptime(totalSeconds) {
  const h = String(Math.floor(totalSeconds / 3600)).padStart(2, '0');
  const m = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, '0');
  const s = String(totalSeconds % 60).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

function startUptimeClock(initialSeconds) {
  uptimeBase = initialSeconds;
  const start = Date.now();
  clearInterval(uptimeTimer);
  uptimeTimer = setInterval(() => {
    const elapsed = uptimeBase + Math.floor((Date.now() - start) / 1000);
    $('uptime').textContent = formatUptime(elapsed);
  }, 1000);
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    method: options.method || 'GET',
    headers: { 'Content-Type': 'application/json' },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  let data = {};
  try { data = await res.json(); } catch {}
  return { ok: res.ok && data.ok !== false, status: res.status, data };
}

async function refreshStatus() {
  const { data } = await api('/api/status');
  setStatusPill(data.status || 'Offline');

  if (data.status === 'Online' && data.authenticated) {
    setupView.classList.add('hidden');
    dashboardView.classList.remove('hidden');
    $('bot-title').textContent = data.name || 'Support Bot';
    $('bot-username').textContent = '@' + (data.username || 'unknown');
    startUptimeClock(data.uptimeSeconds || 0);
    loadReports();
  } else if (data.hasSavedConfig && !data.authenticated) {
    // Bot may be running (resumed after server restart) but this browser isn't logged in.
    setupView.classList.remove('hidden');
    dashboardView.classList.add('hidden');
    $('admin').value = data.adminId || $('admin').value;
    showAlert($('setup-error'), 'A bot is already configured on this server. Enter the matching Admin ID and click Start to reconnect.');
  } else {
    setupView.classList.remove('hidden');
    dashboardView.classList.add('hidden');
    clearInterval(uptimeTimer);
  }
}

$('toggle-token').addEventListener('click', () => {
  const input = $('token');
  const btn = $('toggle-token');
  if (input.type === 'password') {
    input.type = 'text';
    btn.textContent = '🙈';
  } else {
    input.type = 'password';
    btn.textContent = '👁️';
  }
});

$('start-btn').addEventListener('click', async () => {
  const token = $('token').value.trim();
  const admin = $('admin').value.trim();
  const botname = $('botname').value.trim();

  showAlert($('setup-error'), null);

  if (!token) return showAlert($('setup-error'), 'Please paste your BotFather token.');
  if (!admin) return showAlert($('setup-error'), 'Please enter an Admin Telegram ID.');

  $('start-btn').disabled = true;
  $('start-btn-text').textContent = 'Starting...';
  $('start-spinner').classList.remove('hidden');
  setStatusPill('Starting');

  // First, try login in case this bot was already started (e.g. server restarted).
  const loginAttempt = await api('/api/login', { method: 'POST', body: { admin } });

  let result;
  if (loginAttempt.ok) {
    result = loginAttempt;
  } else {
    result = await api('/api/start', { method: 'POST', body: { token, admin, name: botname } });
  }

  $('start-btn').disabled = false;
  $('start-btn-text').textContent = '🚀 Start Bot';
  $('start-spinner').classList.add('hidden');

  if (!result.ok) {
    setStatusPill('Error');
    showAlert($('setup-error'), result.data.error || 'Something went wrong.');
    return;
  }

  $('token').value = '';
  await refreshStatus();
});

$('copy-username').addEventListener('click', () => {
  const username = $('bot-username').textContent;
  navigator.clipboard.writeText(username).then(() => {
    showAlert($('dash-info'), 'Username copied to clipboard.');
    setTimeout(() => showAlert($('dash-info'), null), 2000);
  });
});

$('stop-btn').addEventListener('click', async () => {
  showAlert($('dash-error'), null);
  const result = await api('/api/stop', { method: 'POST' });
  if (!result.ok) return showAlert($('dash-error'), result.data.error || 'Failed to stop bot.');
  await refreshStatus();
});

$('restart-btn').addEventListener('click', async () => {
  showAlert($('dash-error'), null);
  setStatusPill('Starting');
  const result = await api('/api/restart', { method: 'POST' });
  if (!result.ok) {
    showAlert($('dash-error'), result.data.error || 'Failed to restart bot.');
  }
  await refreshStatus();
});

$('test-btn').addEventListener('click', async () => {
  showAlert($('dash-error'), null);
  const result = await api('/api/test', { method: 'POST' });
  if (!result.ok) return showAlert($('dash-error'), result.data.error || 'Test failed.');
  showAlert($('dash-info'), 'Test message sent to the admin chat.');
  setTimeout(() => showAlert($('dash-info'), null), 3000);
});

$('logout-btn').addEventListener('click', async () => {
  if (!confirm('This will stop the bot and permanently remove the saved token. Continue?')) return;
  await api('/api/logout', { method: 'POST' });
  await refreshStatus();
});

async function loadReports() {
  const { ok, data } = await api('/api/reports');
  if (!ok) return;
  const list = $('reports-list');
  $('stat-total').textContent = data.reports.length;
  $('stat-new').textContent = data.reports.filter((r) => r.status === 'New').length;
  $('stat-users').textContent = data.userCount;

  if (data.reports.length === 0) {
    list.innerHTML = '<p class="empty-state">No reports yet.</p>';
    return;
  }

  list.innerHTML = data.reports
    .map(
      (r) => `
    <div class="report-item" data-id="${r.id}">
      <div class="report-item-top">
        <span class="report-user">${escapeHtml(r.fullName)} ${r.username ? '(@' + escapeHtml(r.username) + ')' : ''}</span>
        <span class="status-badge ${r.status}">${r.status}</span>
      </div>
      <div class="report-meta">ID ${r.id} &middot; User ${r.userId} &middot; ${new Date(r.timestamp).toLocaleString()}</div>
      <div class="report-text">${escapeHtml(r.message)}</div>
      <select class="status-select">
        <option value="New" ${r.status === 'New' ? 'selected' : ''}>New</option>
        <option value="Reviewed" ${r.status === 'Reviewed' ? 'selected' : ''}>Reviewed</option>
        <option value="Resolved" ${r.status === 'Resolved' ? 'selected' : ''}>Resolved</option>
      </select>
    </div>`
    )
    .join('');

  list.querySelectorAll('.status-select').forEach((sel) => {
    sel.addEventListener('change', async (e) => {
      const id = e.target.closest('.report-item').dataset.id;
      await api(`/api/reports/${id}/status`, { method: 'POST', body: { status: e.target.value } });
      loadReports();
    });
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

refreshStatus();
pollTimer = setInterval(refreshStatus, 5000);
