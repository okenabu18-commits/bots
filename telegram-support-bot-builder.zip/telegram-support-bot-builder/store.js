const fs = require('fs');
const path = require('path');
const { nanoid } = require('nanoid');

const DATA_DIR = path.join(__dirname, 'data');
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const REPORTS_FILE = path.join(DATA_DIR, 'reports.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

function ensureFile(file, defaultValue) {
  if (!fs.existsSync(file)) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(defaultValue, null, 2));
  }
}

function readJSON(file, fallback) {
  ensureFile(file, fallback);
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJSON(file, data) {
  ensureFile(file, data);
  // Write atomically to avoid corruption if the process is killed mid-write.
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, file);
}

// ---------- Config (encrypted token lives here, never returned to any API response) ----------

function getConfig() {
  return readJSON(CONFIG_FILE, null);
}

function saveConfig(config) {
  writeJSON(CONFIG_FILE, config);
}

function clearConfig() {
  if (fs.existsSync(CONFIG_FILE)) fs.unlinkSync(CONFIG_FILE);
}

// ---------- Reports ----------

function getReports() {
  return readJSON(REPORTS_FILE, []);
}

function addReport({ userId, username, fullName, message }) {
  const reports = getReports();
  const report = {
    id: nanoid(10),
    userId,
    username: username || null,
    fullName: fullName || 'Unknown',
    message,
    timestamp: new Date().toISOString(),
    status: 'New',
  };
  reports.unshift(report);
  writeJSON(REPORTS_FILE, reports);
  return report;
}

function updateReportStatus(id, status) {
  const reports = getReports();
  const idx = reports.findIndex((r) => r.id === id);
  if (idx === -1) return null;
  if (!['New', 'Reviewed', 'Resolved'].includes(status)) return null;
  reports[idx].status = status;
  writeJSON(REPORTS_FILE, reports);
  return reports[idx];
}

// ---------- Users (seen by the bot, for the admin "Users" count) ----------

function getUsers() {
  return readJSON(USERS_FILE, {});
}

function touchUser({ userId, username, fullName }) {
  const users = getUsers();
  users[userId] = {
    userId,
    username: username || null,
    fullName: fullName || 'Unknown',
    lastSeen: new Date().toISOString(),
    firstSeen: users[userId]?.firstSeen || new Date().toISOString(),
  };
  writeJSON(USERS_FILE, users);
}

function countUsers() {
  return Object.keys(getUsers()).length;
}

module.exports = {
  getConfig,
  saveConfig,
  clearConfig,
  getReports,
  addReport,
  updateReportStatus,
  getUsers,
  touchUser,
  countUsers,
};
