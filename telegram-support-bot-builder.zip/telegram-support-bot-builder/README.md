# Telegram Support Bot Builder

A one-page website with its own backend. Paste a BotFather token, set an admin
Telegram ID, click **🚀 Start Bot**, and a full support bot goes live — menus,
a report flow, an admin panel, and a report dashboard — running on the server,
not in your browser tab.

## An important, honest note on "no command line"

The bot has to run **somewhere** as a persistent server process so it keeps
working after you close your laptop — that's true for literally any real
Telegram bot on any platform, it's not something that can be avoided with a
different framework. There is no such thing as a Telegram bot that lives
entirely in a static webpage.

What I *can* guarantee is that **you personally never write or run any code**.
The two options below cover that:

### Option A — One-click hosting (genuinely zero command line)
1. Push this folder to a GitHub repo (drag-and-drop upload on github.com works
   — no git commands needed).
2. Go to [Render](https://render.com), click **New → Blueprint**, and point it
   at your repo. Render reads `render.yaml` in this project and builds +
   deploys everything automatically, including a persistent disk so your bot
   config and reports survive restarts.
3. Open the URL Render gives you — that's your website. Paste your token there.

Any similar "connect a repo and deploy" host (Railway, Fly.io, a VPS control
panel, etc.) works the same way — this project is a standard Node.js app.

### Option B — Run it yourself on a computer that stays on
If you already have Node.js installed, `npm install` then `npm start`, and
open `http://localhost:3000`. You'd need to leave that computer running for
the bot to stay online.

Either way, once the server is running, **everything from that point on is
exactly the UX you asked for**: open the website, paste the token, enter the
admin ID, click Start Bot, and manage everything from the dashboard.

## What's included

- `server.js` — Express backend, session-protected admin API, static file serving.
- `botManager.js` — bot lifecycle (start/stop/restart/resume) and all Telegram logic (menus, callback buttons, report flow, `/admin`, rate limiting).
- `store.js` — JSON-file storage for reports/users/config (no database server to install).
- `crypto-util.js` — AES-256-GCM encryption for the token at rest; a random key is generated on first run and stored only in `data/.secret.key` on the server.
- `public/` — the dark-themed frontend (setup page + live dashboard).
- `render.yaml` — one-click deploy blueprint with a persistent disk.

## Security notes

- The bot token is **never** sent back to the browser, never appears in any
  API response, and is never logged — only a masked form like
  `123456789:••••••3456` is ever shown.
- The token is encrypted at rest (AES-256-GCM) using a key that lives only in
  `data/.secret.key` on the server.
- The dashboard and all bot-control endpoints (`/api/stop`, `/api/restart`,
  `/api/test`, `/api/logout`, `/api/reports`) require an authenticated session,
  created when you start the bot (or by re-entering the matching admin ID if
  you reload after a server restart).
- The `/admin` Telegram command checks the sender's numeric Telegram ID against
  the configured admin ID — no one else can use it.
- Basic per-user rate limiting is applied to both the Telegram bot and the
  HTTP API to prevent abuse.
- Report text is stripped of control characters and length-capped before
  storage or forwarding.

## What was tested

Using a running instance of this server (with a syntactically/format-valid
but non-real token, since a live BotFather token wasn't available in this
environment):

- Missing-admin-ID and malformed-token requests are rejected with clear errors.
- A well-formed-but-fake token correctly triggers Telegram API validation
  (rejected once it reaches `api.telegram.org`).
- `/api/reports`, `/api/stop`, `/api/restart`, `/api/test`, `/api/logout` all
  return `401` without a valid session.
- Report creation, listing, and status updates (`New → Reviewed → Resolved`)
  work end-to-end against the JSON store.
- Login/session flow: starting the bot creates a session; a fresh browser
  session can reconnect with `/api/login` if the admin ID matches.
- Logout clears the stored (encrypted) token and config from disk.
- The server never printed the token to logs or any API response at any point.
- Static frontend, `app.js`, and `style.css` all serve correctly.

**What could not be tested here:** actual message exchange with Telegram
(`/start`, inline buttons, `/admin`, live report delivery) requires a real
BotFather token and outbound access to `api.telegram.org`, neither of which
was available in this sandboxed environment. The Telegram-facing code
(`botManager.js`) uses the standard, widely-used `node-telegram-bot-api`
library in the conventional way (polling mode, `onText`, `callback_query`,
`sendMessage`) — once you paste a real token, this should work directly. If
anything about the live bot behavior isn't right, tell me the exact error and
I'll fix it.
